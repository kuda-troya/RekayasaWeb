<h3>Insert Data Customer</h3>
<?php echo form_open('customer/add');?>

<table class="table table-bordered">
    <tr>
        <td>Nama</td>
        <td>
        <?php echo form_input('name','',"placeholder='Nama Lengkap' class='form-control'"); ?>
        </td>    
    </tr>
    <tr>
        <td>kota</td>
        <td>
        <?php echo form_input('city','',"placeholder='Nama Kota' class='form-control'"); ?>
        </td>    
    </tr>
    <tr>
        <td>No Handphone</td>
        <td>
        <?php echo form_input('phone','',"placeholder='Nomor Handphone' class='form-control'"); ?>
        </td>    
    </tr>
    <tr>
        <td colspan="2">
        <?php echo form_submit('submit','simpan',"class='btn btn-dangetbtn-sm'"); ?>
        <?php echo anchor('customer','Kembali',array('class'=>'btn btn-danger btn-sm')); ?>
        </td>
    </tr>
</table>   
<?php echo form_close() ?> 