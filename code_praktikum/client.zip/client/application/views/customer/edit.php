<h3>Edit data Customer</h3>
<?php 
echo form_open('customer/edit');
echo form_hidden('id',$customer[0]->customerID);
?>
<table class="table table-bordered">
    <tr>
        <td>Nama</td>
        <td>
        <?php
        echo form_input('name',$customer[0]->customerName,"placeholder='Nama Lengkap' class='form-control'");
        ?>
        </td>    
    </tr>
    <tr>
        <td>kota</td>
        <td>
        <?php
        echo form_input('city',$customer[0]->customerCity,"placeholder='Nama Kota' class='form-control'");
        ?>
        </td>    
    </tr>
    <tr>
        <td>No Handphone</td>
        <td>
        <?php
        echo form_input('phone',$customer[0]->customerPhone,"placeholder='Nomor Handphone' class='form-control'");
        ?>
        </td>    
    </tr>
    <tr>
        <td colspan="2">
        <?php echo form_submit('submit','Simpan',"class='btn btn-dangetbtn-sm'"); ?>
        <?php echo anchor('customer','Kembali',array('class'=>'btn btn-danger btn-sm')); ?>
        </td>
    </tr>
</table> 