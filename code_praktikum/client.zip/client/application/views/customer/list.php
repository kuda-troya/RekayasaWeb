<h3>Data Customer</h3>

<?php 
echo anchor('customer/add','ENTRY',array('class'=>'btn btn-danger btn-sm'));
?>

<table class="table table-bordered">
    <th>
        <td>No</td>
        <td>Nama Lengkap</td>
        <td>Alamat</td>
        <td>No HP</td>
        <td colspan="2">Action</td>
    </th>

    <?php
    $no=1;
    foreach($customers as $customer){
        echo"<tr>
        <td width='10'>$no</td>
        <td>$customer->customerName</td>
        <td>$customer->customerCity</td>
        <td>$customer->customerPhone</td>
        <td width='20'>";
        echo anchor('customer/edit/'.$customer->customerID,'EDIT',array('class'=>'btn btn-danger btn-sm'));
        echo"</td><td width='20'>";
        echo anchor('customer/delete/'.$customer->customerID,'DELETE',array('class'=>'btn btn-danger btn-sm'));
        echo"</td>
        </tr>";
        $no++;
    }
    ?>
</table>