/*
Navicat MySQL Data Transfer

Source Server         : Localhost
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : xml

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-12-01 16:28:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for profile
-- ----------------------------
DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `idProfile` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(35) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `progdi` varchar(50) NOT NULL,
  PRIMARY KEY (`idProfile`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of profile
-- ----------------------------
INSERT INTO `profile` VALUES ('1', 'G.211.20.0212', 'Wiro Sableng', 'Teknik Informatika');
INSERT INTO `profile` VALUES ('2', 'G.231.20.0505', 'Pierrally', 'Teknik Informatika');
INSERT INTO `profile` VALUES ('3', 'G.111.20.0008', 'Putri Saras', 'Sistem Informasi');
INSERT INTO `profile` VALUES ('4', 'G.111.20.0909', 'Ray Fireman', 'Sistem Informasi');
INSERT INTO `profile` VALUES ('5', 'G.311.20.0101', 'Veronica', 'Ilmu Komunikasi');
INSERT INTO `profile` VALUES ('6', 'G.321.20.0046', 'Rossidionso', 'Ilmu Komunikasi');
INSERT INTO `profile` VALUES ('7', 'B.211.10.0029', 'Nara Ritzu', 'Akuntansi');
INSERT INTO `profile` VALUES ('8', 'B.211.12.0012', 'Monica', 'Akuntansi');
INSERT INTO `profile` VALUES ('9', 'B.211.10.0029', 'Nara Ritzu', 'Akuntansi');
INSERT INTO `profile` VALUES ('10', 'B.211.12.0012', 'Monica', 'Akuntansi');
INSERT INTO `profile` VALUES ('11', 'B.211.10.0029', 'Nara Ritzu', 'Akuntansi');
INSERT INTO `profile` VALUES ('12', 'B.211.12.0012', 'Monica', 'Akuntansi');
INSERT INTO `profile` VALUES ('13', 'B.211.10.0029', 'Nara Ritzu', 'Akuntansi');
INSERT INTO `profile` VALUES ('14', 'B.211.12.0012', 'Monica', 'Akuntansi');

-- ----------------------------
-- Table structure for profile1
-- ----------------------------
DROP TABLE IF EXISTS `profile1`;
CREATE TABLE `profile1` (
  `idProfile` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(35) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `progdi` varchar(50) NOT NULL,
  PRIMARY KEY (`idProfile`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of profile1
-- ----------------------------
INSERT INTO `profile1` VALUES ('1', 'G.211.20.0212', 'Wiro Sableng', 'Teknik Informatika');
INSERT INTO `profile1` VALUES ('2', 'G.231.20.0505', 'Pierrally', 'Teknik Informatika');
INSERT INTO `profile1` VALUES ('3', 'G.111.20.0008', 'Putri Saras', 'Sistem Informasi');
INSERT INTO `profile1` VALUES ('4', 'G.111.20.0909', 'Ray Fireman', 'Sistem Informasi');
INSERT INTO `profile1` VALUES ('5', 'G.311.20.0101', 'Veronica', 'Ilmu Komunikasi');
INSERT INTO `profile1` VALUES ('6', 'G.321.20.0046', 'Rossidionso', 'Ilmu Komunikasi');

-- ----------------------------
-- Table structure for profile2
-- ----------------------------
DROP TABLE IF EXISTS `profile2`;
CREATE TABLE `profile2` (
  `idProfile` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(35) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `progdi` varchar(50) NOT NULL,
  PRIMARY KEY (`idProfile`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of profile2
-- ----------------------------
INSERT INTO `profile2` VALUES ('1', 'G.211.20.0212', 'Wiro Sableng', 'Teknik Informatika');
INSERT INTO `profile2` VALUES ('2', 'G.231.20.0505', 'Pierrally', 'Teknik Informatika');
INSERT INTO `profile2` VALUES ('3', 'G.111.20.0008', 'Putri Saras', 'Sistem Informasi');
INSERT INTO `profile2` VALUES ('4', 'G.111.20.0909', 'Ray Fireman', 'Sistem Informasi');
INSERT INTO `profile2` VALUES ('5', 'G.311.20.0101', 'Veronica', 'Ilmu Komunikasi');
INSERT INTO `profile2` VALUES ('6', 'G.321.20.0046', 'Rossidionso', 'Ilmu Komunikasi');
INSERT INTO `profile2` VALUES ('7', '', 'Wiro Sableng', 'Teknik Informatika');
INSERT INTO `profile2` VALUES ('8', '', 'Pierrally', 'Teknik Informatika');
INSERT INTO `profile2` VALUES ('9', 'B.211.10.0029', 'Nara Ritzu', 'Akuntansi');
INSERT INTO `profile2` VALUES ('10', 'B.211.12.0012', 'Monica', 'Akuntansi');
