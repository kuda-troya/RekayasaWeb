<?Php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xml";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql="SELECT nim,nama,progdi FROM profile"; 
$str ="<?xml version="1.0" encoding="UTF-8"?>n<student>";

foreach ($dbo->query($sql) as $row) {
$str .= "\n<details>\n\t\t\t<id>$row[id]</id>\n\t\t\t<name>$row[name]</name> ";

$str .= "\n\t\t\t  <class>$row[class]</class>\n</details>";
}
$str.= "\n</student>";
//$str=nl2br($str);
//echo htmlspecialchars($str); // remove this line if you are writing to file
echo $str;
/////////////////////////////  
/// Write to file ////////////
/*
$file_name="test_file.xml";               // file name
$fp = fopen ($file_name, "w");  
// Open the file in write mode, if file does not exist then it will be created.
fwrite ($fp,$str);          // entering data to the file
fclose ($fp);                                // closing the file pointer
chmod($file_name,0777);  
*/
?>