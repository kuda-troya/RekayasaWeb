<?php
$myXMLData =
"<?xml version='1.0' encoding='UTF-8'?> 
<catatan> 
    <untuk>Mahasiswa TI</untuk> 
    <dari>Dosen USM</dari>
    <fakultas>FTIK JOSS</fakultas>
    <pesan>Jangan lupa belajar Mandiri!</pesan>
</catatan>";

$xml=simplexml_load_string($myXMLData) or die("Error: Cannot create object");
print_r($xml);
?>