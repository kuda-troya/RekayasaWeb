<?php
$xml=simplexml_load_file("02_exam.xml") or die("Error: Cannot create object");
echo "<table border='1'><tr><th>Nim</th><th>Nama</th><th>Alamat</th></tr>";
foreach($xml->children() as $mhs) {
    echo "<tr>";
    echo "<td>".$mhs->nim . "</td>";
    echo "<td>".$mhs->nama . "</td>";
    echo "<td>".$mhs->alamat . "</td>";
    echo "</tr>";
}
echo "</table>";
?>