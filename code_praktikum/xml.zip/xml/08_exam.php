<?php
header('Content-type: text/xml');
header('Pragma: public');
header('Cache-control: private');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "xml";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
echo "<profile>";

$sql = "SELECT nim,nama,progdi FROM profile";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // menampilkan data dari setiap baris
  while($row=$result->fetch_assoc()) {
    echo "<mahasiswa nim='".$row['nim']."'>"; 
    echo "<nama>".$row['nama']."</nama>"; 
    echo "<progdi>".$row['progdi']."</progdi>";
    echo "</mahasiswa>";
  }
} else {
  echo "0 results";
}
$conn->close();

echo "</profile>";
?>