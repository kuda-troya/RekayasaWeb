<?php
header("Content-type: text/xml");
echo "<?xml version='1.0' encoding='UTF-8'?>";
echo "<catatan>"; 
echo "<untuk>Mahasiswa TI</untuk>"; 
echo "<dari>Dosen USM</dari>";
echo "<fakultas>FTIK JOSS</fakultas>";
echo "<pesan>Jangan lupa belajar Mandiri!</pesan>";
echo "</catatan>";
?>