/*
Navicat MySQL Data Transfer

Source Server         : Localhost
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : json

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-12-01 16:28:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for mahasiswa
-- ----------------------------
DROP TABLE IF EXISTS `mahasiswa`;
CREATE TABLE `mahasiswa` (
  `idMhs` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(15) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `fakultas` varchar(50) NOT NULL,
  `progdi` varchar(50) NOT NULL,
  PRIMARY KEY (`idMhs`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of mahasiswa
-- ----------------------------
INSERT INTO `mahasiswa` VALUES ('1', 'A.111.11.0011', 'Hakim Bao', 'Hukum', 'S1-Hukum');
INSERT INTO `mahasiswa` VALUES ('2', 'B.111.10.0021', 'Man German', 'Ekonomi', 'S1-Manajemen');
INSERT INTO `mahasiswa` VALUES ('3', 'B.211.12.0029', 'Melati', 'Ekonomi', 'S1-Akuntansi');
INSERT INTO `mahasiswa` VALUES ('4', 'C.131.13.0013', 'Jarwo Kuwat', 'Teknik', 'S1-Teknik Sipil');
INSERT INTO `mahasiswa` VALUES ('5', 'D.141.14.0141', 'Desi', 'Teknologi Pertanian', 'S1-Teknologi Hasil Pertanian');
INSERT INTO `mahasiswa` VALUES ('6', 'F.131.15.0013', 'Charles Francis Xavier', 'Psikologi', 'S1-Psikologi');
INSERT INTO `mahasiswa` VALUES ('7', 'G.111.12.0120', 'Mad Max', 'Teknologi Informasi dan Komunikasi', 'S1-Sistem Informasi');
