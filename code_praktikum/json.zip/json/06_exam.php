<?php

function curl($url){
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    $output = curl_exec($ch); 
    curl_close($ch);      
    return $output;
}

$send = curl('http://localhost/rekayasa_web/json/04_exam.php');

$data = json_decode($send, TRUE);
?>
<h2>Json ke HTML</h2>
<table border='1'>
    <tr>
        <th>Nim</th><th>Nama</th><th>Fakultas</th><th>Progdi</th>
    </tr>
    <?php foreach($data as $row){ ?>
    <tr>
        <td><?php echo $row['nim']; ?></td>
        <td><?php echo $row['nama']; ?></td>
        <td><?php echo $row['fakultas']; ?></td>
        <td><?php echo $row['progdi']; ?></td>
    </tr>
    <?php } ?>
</table>