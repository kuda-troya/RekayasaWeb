<?php
$conn = mysqli_connect("localhost", "root", "", "json");
$query= mysqli_query($conn,"SELECT * FROM mahasiswa");


if (mysqli_num_rows($query) > 0) {
    $data=array();
    while($row = mysqli_fetch_assoc($query)) {
        $data[]=$row;
    }
    
    echo json_encode($data);
}else{
    echo "Data Kosong";
}
?>