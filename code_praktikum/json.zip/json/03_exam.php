<h2>JSON dirubah ke PHP Associative Arrays</h2>
<?php
$data='[{"nama":"Andi","nilai":80},
{"nama":"Budi","nilai":40},
{"nama":"Candra","nilai":20},
{"nama":"Denis","nilai":70},
{"nama":"Fabrian","nilai":100},
{"nama":"Gunawan","nilai":90},
{"nama":"Hendra","nilai":35},
{"nama":"Ian","nilai":75}]';

$decode=json_decode($data);
print_r($decode);
?>

