/*
Navicat MySQL Data Transfer

Source Server         : Localhost
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : webservice

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-12-01 16:26:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `customerName` varchar(40) CHARACTER SET latin1 NOT NULL,
  `customerCity` text CHARACTER SET latin1 NOT NULL,
  `customerPhone` varchar(12) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`customerID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'alba', 'boja kendal', '084142141');
INSERT INTO `customer` VALUES ('2', 'albi', 'semarang', '08123131');
INSERT INTO `customer` VALUES ('3', 'Gery Coklat', 'Kacang Garuda', '123456');
INSERT INTO `customer` VALUES ('10', 'Pepeng Sukarya', 'Bandung', '081245');
